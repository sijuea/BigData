create
    definer = root@localhost function rand_num_seed(from_num int, to_num int, seed mediumtext) returns int
BEGIN
    DECLARE i INT DEFAULT 0;
    SET i = FLOOR(from_num +RAND(seed+UNIX_TIMESTAMP(NOW()))*(to_num -from_num+1))   ;
    RETURN i;
END;

