create
    definer = root@localhost procedure update_order(IN operate_time_string varchar(20))
BEGIN
    DECLARE v_operate_time DATETIME DEFAULT NULL;
    SET v_operate_time=DATE_FORMAT(operate_time_string,'%Y-%m-%d');
    UPDATE order_info o SET   o.`order_status`=o.`order_status`+rand_num_seed(0,1,o.id) ,operate_time= IF( rand_num_seed(0,1,o.id) >0 , DATE_ADD(v_operate_time ,INTERVAL rand_num(30,20*3600) SECOND),operate_time)
    WHERE o.`order_status`<5;
END;

